# Ticket 2 — Pre-built comparison

Prices checked 2026-11-23. Each alternative includes a 1 TB SSD, at least 16 GB of RAM, the same monitor allowance as the custom build, and an OS. All values are in KZT.

| Role | Pre-built tower | Tower | Monitor | OS | Workstation | Custom | Quote |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| Accountant | [ARG Office T01, Core i5-12400, 16 GB, 1 TB SSD](https://www.sulpak.kz/g/personalniye-kompyuteriy-arg-officet01-i5-16-1024) | 339,990 | 48,000 | 159,999 | 547,989 | 578,150 | [accountant-prebuilt.png](vendor-quotes/accountant-prebuilt.png) |
| Sales manager | [ARG Office T01, Core i5-12400, 16 GB, 1 TB SSD](https://www.sulpak.kz/g/personalniye-kompyuteriy-arg-officet01-i5-16-1024) | 339,990 | 48,000 | 159,999 | 547,989 | 563,150 | [sales-prebuilt.png](vendor-quotes/sales-prebuilt.png) |
| Web developer | [WW-KZ, Core i5-14400, RTX 3050 6 GB, 32 GB DDR5, 1 TB SSD](https://shop.kz/offer/kompyuter-igrovoy-ww-kz-intel-core-i5-14400-rtx-3050-6-gb-1-tb-ssd-32-gb-ddr-5/) | 731,390 | 48,000 | 0 | 779,390 | 651,202 | [developer-prebuilt.png](vendor-quotes/developer-prebuilt.png) |
| Designer | [WW-KZ, Ryzen 5 7500F, RTX 5060 Ti 8 GB, 32 GB DDR5, 1 TB SSD](https://shop.kz/offer/kompyuter-igrovoy-ww-kz-amd-ryzen-5-7500f-rtx-5060ti-8-gb-1-tb-ssd-32-gb-ddr-5/) | 915,190 | 112,400 | 159,999 | 1,182,207 | 1,184,117 | [designer-prebuilt.png](vendor-quotes/designer-prebuilt.png) |
| **Total** | | | | | **3,062,957** | **2,974,709** | |

The ARG tower is suitable for both office roles. Sulpak showed display stock in two Almaty stores. Confirm two units if choosing this route. All three tower listings specified no included OS. The comparison adds [Windows 11 Pro](vendor-quotes/accountant-os.png) to the two office PCs and the designer PC, and [Ubuntu Desktop](vendor-quotes/developer-os.png) to the developer PC. Monitor prices come from the [Samsung](vendor-quotes/accountant-monitor.png) and [Dahua](vendor-quotes/designer-monitor.png) quotes.

Buying pre-built saves assembly and initial troubleshooting time and gives one seller to contact about the tower. Shop.kz listed 12 months of warranty for each WW-KZ tower. The developer pays for a GPU that the assumed work does not need. The designer gets a faster GPU tier but gives up the Ryzen 7 7700 for a six-core Ryzen 5. With custom builds I can choose the board, PSU and cooling. I would check warranty terms before replacing internal parts in a pre-built PC.
